package enums

enum class SpotifyMenu(val id: String, val desc: String) {
    LOGIN("1", "gunakan Username dan Password"),
    PROFILE("2", " ")
}